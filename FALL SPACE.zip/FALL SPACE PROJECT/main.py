import pygame
from moviepy.editor import VideoFileClip
from pygame import mixer
from fighter import Fighter
from tkinter import *
from tkinter import messagebox
from PIL import ImageTk, Image
from tkinter.filedialog import askopenfile
from tkinter import filedialog as fd
import os
import pickle  #pikl - kiritilgan suzlarni baytga aylantirish. Unpickle - teskarisi
root = Tk()
root.geometry("1920x1080")
root.title ("Войти в систему")

pygame.display.set_caption('My video!')

clip = VideoFileClip('assets/images/background/intro.wmv')
clip.preview()

#load music and sounds
pygame.mixer.music.load("assets/audio/intro.mp3")
pygame.mixer.music.set_volume(0.5)
pygame.mixer.music.play(-1, 0.0, 5000)



def registration():   #Registratsiya qilish bo`limi
    text = Label(text="Для входа в систему - зарегистрируйтесь!")
    text.config(font=("forte",16,"bold"))
    text.config(bg="#7561db")
    text.config(fg="#FFFFE0")
    text_log = Label(text="Введите ваш логин:")
    text_log.config(font=("forte",16,"bold"))
    text_log.config(bg="#dd17f7")
    text_log.config(fg="#FFFFE0")
    registr_login = Entry()
    text_password1 = Label(text="Введите ваш парол:")
    text_password1.config(font=("forte",16,"bold"))
    text_password1.config(bg="#dd17f7")
    text_password1.config(fg="#FFFFE0")
    registr_password1 = Entry(show="*")
    text_password2 = Label(text="подвердите ваш парол:")
    text_password2.config(font=("forte",16,"bold"))
    text_password2.config(bg="#dd17f7")
    text_password2.config(fg="#FFFFE0")
    registr_password2 = Entry(show="*")
    button_registr = Button(text="Зарегистрироваться!", command=lambda: save()) #Registr tugmasi bosilganda save funksiyasi iwga tuwadi
    button_registr.config(font=("forte",16,"bold"))
    button_registr.config(bg="#7561db")
    button_registr.config(fg="#FFFFE0")

    text.pack()
    text_log.pack()
    registr_login.pack()
    text_password1.pack()
    registr_password1.pack()
    text_password2.pack()
    registr_password2.pack()
    button_registr.pack()

    def save():  #login va parolni saqlash
        login_pass_save = {}
        login_pass_save[registr_login.get()] = registr_password1.get()
        f = open("login.txt", "wb")
        pickle.dump(login_pass_save, f)
        f.close()
        login()


def login():    #avtorizatsiya bo`limi
    text_log = Label(text="Теперь вы можете войти в систему! ")
    text_log.config(font=("forte",16,"bold"))
    text_log.config(bg="#7561db")
    text_log.config(fg="#FFFFE0")
    text_enter_login = Label(text="Введите ваш логин:")
    text_enter_login.config(font=("forte",16,"bold"))
    text_enter_login.config(bg="#dd17f7")
    text_enter_login.config(fg="#FFFFE0")
    enter_login = Entry()
    text_enter_password = Label(text="Введите ваш парол:")
    text_enter_password.config(font=("forte",16,"bold"))
    text_enter_password.config(bg="#dd17f7")
    text_enter_password.config(fg="#FFFFE0")
    enter_password = Entry(show="*")
    button_enter = Button(text="Войти", command=lambda: log_pass()) #kirish bosilganda login va parol tekshiriladi!
    button_enter.config(font=("forte",16,"bold"))
    button_enter.config(bg="#7561db")
    button_enter.config(fg="#FFFFE0")

    # button.config(state= DISABLED)
    text_log.pack()
    text_enter_login.pack()
    enter_login.pack()
    text_enter_password.pack()
    enter_password.pack()
    button_enter.pack()

    def log_pass(): #login va parolni tekshirish
        f = open("login.txt", "rb") #login.txtni uqish  rb-bu read
        a = pickle.load(f)
        f.close()
        if enter_login.get() in a:
            if enter_password.get() ==a[enter_login.get()]: #agar parol va login tugri bulsa
               messagebox.showinfo("Вход выполнен", "Вы успешно вошли в аккаунт")
            else:
                messagebox.showerror("Ошибка", "Вы ввели не правилный логин или пароль")
        else:
            messagebox.showerror("Ошибка", "Вы ввели не правилный пароль")

registration()
root.mainloop()



mixer.init()
pygame.init()

#create game window
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 600

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("FALL SPACE")


#set framerate
clock = pygame.time.Clock()
FPS = 60

#define colours
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)

#define game variables
intro_count = 15
last_count_update = pygame.time.get_ticks()
score = [0, 0]#player scores. [P1, P2]
round_over = False
ROUND_OVER_COOLDOWN = 2000

#define fighter variables
WARRIOR_SIZE = 162
WARRIOR_SCALE = 4
WARRIOR_OFFSET = [72, 56]
WARRIOR_DATA = [WARRIOR_SIZE, WARRIOR_SCALE, WARRIOR_OFFSET]
WIZARD_SIZE = 250
WIZARD_SCALE = 3
WIZARD_OFFSET = [112, 107]
WIZARD_DATA = [WIZARD_SIZE, WIZARD_SCALE, WIZARD_OFFSET]

#load music and sounds
pygame.mixer.music.load("assets/audio/fatality.mp3")
pygame.mixer.music.set_volume(0.5)
pygame.mixer.music.play(-1, 0.0, 5000)
sword_fx = pygame.mixer.Sound("assets/audio/sword.wav")
sword_fx.set_volume(0.5)
magic_fx = pygame.mixer.Sound("assets/audio/magic.wav")
magic_fx.set_volume(0.75)

#load background image
bg_image = pygame.image.load("assets/images/background/background.png").convert_alpha()

#load spritesheets
warrior_sheet = pygame.image.load("assets/images/warrior/Sprites/warrior.png").convert_alpha()
wizard_sheet = pygame.image.load("assets/images/wizard/Sprites/wizard.png").convert_alpha()

#load vicory image
victory_img = pygame.image.load("assets/images/icons/victory.png").convert_alpha()

#define number of steps in each animation
WARRIOR_ANIMATION_STEPS = [10, 8, 1, 7, 7, 3, 7]
WIZARD_ANIMATION_STEPS = [8, 8, 1, 8, 8, 3, 7]

#define font
count_font = pygame.font.Font("assets/fonts/turok.ttf", 80)
score_font = pygame.font.Font("assets/fonts/turok.ttf", 30)

#function for drawing text
def draw_text(text, font, text_col, x, y):
  img = font.render(text, True, text_col)
  screen.blit(img, (x, y))

#function for drawing background
def draw_bg():
  scaled_bg = pygame.transform.scale(bg_image, (SCREEN_WIDTH, SCREEN_HEIGHT))
  screen.blit(scaled_bg, (0, 0))

#function for drawing fighter health bars
def draw_health_bar(health, x, y):
  ratio = health / 100
  pygame.draw.rect(screen, WHITE, (x - 2, y - 2, 404, 34))
  pygame.draw.rect(screen, RED, (x, y, 400, 30))
  pygame.draw.rect(screen, YELLOW, (x, y, 400 * ratio, 30))


#create two instances of fighters
fighter_1 = Fighter(1, 200, 310, False, WARRIOR_DATA, warrior_sheet, WARRIOR_ANIMATION_STEPS, sword_fx)
fighter_2 = Fighter(2, 700, 310, True, WIZARD_DATA, wizard_sheet, WIZARD_ANIMATION_STEPS, magic_fx)

#game loop
run = True
while run:

  clock.tick(FPS)

  #draw background
  draw_bg()

  #show player stats
  draw_health_bar(fighter_1.health, 20, 20)
  draw_health_bar(fighter_2.health, 580, 20)
  draw_text("P1: " + str(score[0]), score_font, RED, 20, 60)
  draw_text("P2: " + str(score[1]), score_font, RED, 580, 60)

  #update countdown
  if intro_count <= 0:
    #move fighters
    fighter_1.move(SCREEN_WIDTH, SCREEN_HEIGHT, screen, fighter_2, round_over)
    fighter_2.move(SCREEN_WIDTH, SCREEN_HEIGHT, screen, fighter_1, round_over)
  else:
    #display count timer
    draw_text(str(intro_count), count_font, RED, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 3)
    #update count timer
    if (pygame.time.get_ticks() - last_count_update) >= 1000:
      intro_count -= 1
      last_count_update = pygame.time.get_ticks()

  #update fighters
  fighter_1.update()
  fighter_2.update()

  #draw fighters
  fighter_1.draw(screen)
  fighter_2.draw(screen)

  #check for player defeat
  if round_over == False:
    if fighter_1.alive == False:
      score[1] += 1
      round_over = True
      round_over_time = pygame.time.get_ticks()
    elif fighter_2.alive == False:
      score[0] += 1
      round_over = True
      round_over_time = pygame.time.get_ticks()
  else:
    #display victory image
    screen.blit(victory_img, (360, 150))
    if pygame.time.get_ticks() - round_over_time > ROUND_OVER_COOLDOWN:
      round_over = False
      intro_count = 3
      fighter_1 = Fighter(1, 200, 310, False, WARRIOR_DATA, warrior_sheet, WARRIOR_ANIMATION_STEPS, sword_fx)
      fighter_2 = Fighter(2, 700, 310, True, WIZARD_DATA, wizard_sheet, WIZARD_ANIMATION_STEPS, magic_fx)

  #event handler
  for event in pygame.event.get():
    if event.type == pygame.QUIT:
      run = False


  #update display
  pygame.display.update()


#exit pygame
pygame.quit()